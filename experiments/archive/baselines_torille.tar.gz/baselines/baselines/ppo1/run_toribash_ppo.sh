python3 run_toribash.py --env Toribash-RunAway-v0 --num-timesteps 5000000 --seed 0 > RunAway1.log &
python3 run_toribash.py --env Toribash-SelfDestruct-v0 --num-timesteps 5000000 --seed 0 > SelfDestruct1.log &
python3 run_toribash.py --env Toribash-DestroyUke-v0 --num-timesteps 5000000 --seed 0 > DestroyUke1.log &

python3 run_toribash.py --env Toribash-RunAway-v0 --num-timesteps 5000000 --seed 1 > RunAway2.log &
python3 run_toribash.py --env Toribash-SelfDestruct-v0 --num-timesteps 5000000 --seed 1 > SelfDestruct2.log &
python3 run_toribash.py --env Toribash-DestroyUke-v0 --num-timesteps 5000000 --seed 1 > DestroyUke2.log &

python3 run_toribash.py --env Toribash-RunAway-v0 --num-timesteps 5000000 --seed 2 > RunAway3.log &
python3 run_toribash.py --env Toribash-SelfDestruct-v0 --num-timesteps 5000000 --seed 2 > SelfDestruct3.log &
python3 run_toribash.py --env Toribash-DestroyUke-v0 --num-timesteps 5000000 --seed 2 > DestroyUke3.log &

python3 run_toribash.py --env Toribash-RunAway-v0 --num-timesteps 5000000 --seed 3 > RunAway4.log &
python3 run_toribash.py --env Toribash-SelfDestruct-v0 --num-timesteps 5000000 --seed 3 > SelfDestruct4.log &
python3 run_toribash.py --env Toribash-DestroyUke-v0 --num-timesteps 5000000 --seed 3 > DestroyUke4.log &

python3 run_toribash.py --env Toribash-RunAway-v0 --num-timesteps 5000000 --seed 4 > RunAway5.log &
python3 run_toribash.py --env Toribash-SelfDestruct-v0 --num-timesteps 5000000 --seed 4 > SelfDestruct5.log &
python3 run_toribash.py --env Toribash-DestroyUke-v0 --num-timesteps 5000000 --seed 4 > DestroyUke5.log &
