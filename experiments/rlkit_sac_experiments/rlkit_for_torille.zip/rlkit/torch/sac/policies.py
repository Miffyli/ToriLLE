import numpy as np
import torch
from torch import nn as nn

from rlkit.policies.base import ExplorationPolicy, Policy
from rlkit.torch.distributions import TanhNormal
from rlkit.torch.networks import Mlp

from torch.distributions import OneHotCategorical

# TODO consider reusing some code. Now we have copies 
#      of same code everywhere

class MultiCategoricalPolicy(Mlp, ExplorationPolicy):
    """
    MultiCategorical policy
    """
    def __init__(
            self,
            hidden_sizes,
            obs_dim,
            num_categoricals,
            num_categories, 
            init_w=1e-3,
            **kwargs
    ):
        self.save_init_params(locals())
        super().__init__(
            hidden_sizes,
            input_size=obs_dim,
            output_size=num_categoricals * num_categories,
            init_w=init_w,
            **kwargs
        )
        self.num_categoricals = num_categoricals
        self.num_categories = num_categories


    def get_action(self, obs_np, deterministic=False):
        actions = self.get_actions(obs_np[None], deterministic=deterministic)
        return actions[0], {}

    def get_actions(self, obs_np, deterministic=False):
        onehots = self.eval_np(obs_np, deterministic=deterministic)[0]
        return onehots

    def forward(
            self,
            obs,
            reparameterize=False,
            deterministic=False,
            return_log_prob=False,
    ):
        """
        :param obs: Observation
        :param deterministic: If True, do not sample
        :param return_log_prob: If True, return a sample and its log probability
        """
        # Run through the network part of this policy
        h = obs
        for i, fc in enumerate(self.fcs):
            h = self.hidden_activation(fc(h))
        # Do reshaping
        logits = self.last_fc(h).view(-1, self.num_categoricals, self.num_categories)

        action = None
        log_prob = None
        if deterministic:
            # Maximum of logits
            # TODO probably could be done with some function faster
            action = torch.zeros(logits.shape, dtype=torch.int)
            for bi in range(logits.shape[0]):
                for ci in range(logits.shape[1]):
                    action[bi,ci] = (logits[bi,ci] == logits[bi,ci].max()).type(torch.int)
        else:
            dist = OneHotCategorical(logits=logits)
            action = dist.sample()
            if return_log_prob:
                if reparameterize is True:
                    # No rsample for Categorical in PyTorch
                    raise NotImplementedError
                else:
                    log_prob = dist.log_prob(action)
                    # Joint likelihood
                    log_prob = log_prob.sum(dim=1)
        return (action, log_prob)

class CategoricalPolicy(Mlp, ExplorationPolicy):
    """
    Categorical policy
    """
    def __init__(
            self,
            hidden_sizes,
            obs_dim,
            action_dim,
            init_w=1e-3,
            **kwargs
    ):
        self.save_init_params(locals())
        super().__init__(
            hidden_sizes,
            input_size=obs_dim,
            output_size=action_dim,
            init_w=init_w,
            **kwargs
        )

    def get_action(self, obs_np, deterministic=False):
        actions = self.get_actions(obs_np[None], deterministic=deterministic)
        return actions[0], {}

    def get_actions(self, obs_np, deterministic=False):
        onehots = self.eval_np(obs_np, deterministic=deterministic)[0]
        return np.argmax(onehots, axis=1)

    def forward(
            self,
            obs,
            reparameterize=False,
            deterministic=False,
            return_log_prob=False,
    ):
        """
        :param obs: Observation
        :param deterministic: If True, do not sample
        :param return_log_prob: If True, return a sample and its log probability
        """
        # Run through the network part of this policy
        h = obs
        for i, fc in enumerate(self.fcs):
            h = self.hidden_activation(fc(h))
        logits = self.last_fc(h)

        action = None
        log_prob = None
        if deterministic:
            # Replace highest logit with 1 and rest with 0
            # TODO make prettier/faster?
            action = torch.zeros(logits.shape, dtype=torch.int)
            for bi in range(logits.shape[0]):
                action[bi] = (logits[bi] == logits[bi].max()).type(torch.int)
        else:
            dist = OneHotCategorical(logits=logits)
            action = dist.sample()
            if return_log_prob:
                if reparameterize is True:
                    # No rsample for Categorical in PyTorch
                    raise NotImplementedError
                else:
                    log_prob = dist.log_prob(action)
        return (action, log_prob)

class TanhGaussianPolicy(Mlp, ExplorationPolicy):
    """
    Usage:

    ```
    policy = TanhGaussianPolicy(...)
    action, mean, log_std, _ = policy(obs)
    action, mean, log_std, _ = policy(obs, deterministic=True)
    action, mean, log_std, log_prob = policy(obs, return_log_prob=True)
    ```

    Here, mean and log_std are the mean and log_std of the Gaussian that is
    sampled from.

    If deterministic is True, action = tanh(mean).
    If return_log_prob is False (default), log_prob = None
        This is done because computing the log_prob can be a bit expensive.
    """

    LOG_SIG_MAX = 2
    LOG_SIG_MIN = -20

    def __init__(
            self,
            hidden_sizes,
            obs_dim,
            action_dim,
            std=None,
            init_w=1e-3,
            **kwargs
    ):
        self.save_init_params(locals())
        super().__init__(
            hidden_sizes,
            input_size=obs_dim,
            output_size=action_dim,
            init_w=init_w,
            **kwargs
        )
        self.log_std = None
        self.std = std
        if std is None:
            last_hidden_size = obs_dim
            if len(hidden_sizes) > 0:
                last_hidden_size = hidden_sizes[-1]
            self.last_fc_log_std = nn.Linear(last_hidden_size, action_dim)
            self.last_fc_log_std.weight.data.uniform_(-init_w, init_w)
            self.last_fc_log_std.bias.data.uniform_(-init_w, init_w)
        else:
            self.log_std = np.log(std)
            assert TanhGaussianPolicy.LOG_SIG_MIN <= self.log_std <= TanhGaussianPolicy.LOG_SIG_MAX

    def get_action(self, obs_np, deterministic=False):
        actions = self.get_actions(obs_np[None], deterministic=deterministic)
        return actions[0, :], {}

    def get_actions(self, obs_np, deterministic=False):
        return self.eval_np(obs_np, deterministic=deterministic)[0]

    def forward(
            self,
            obs,
            reparameterize=True,
            deterministic=False,
            return_log_prob=False,
    ):
        """
        :param obs: Observation
        :param deterministic: If True, do not sample
        :param return_log_prob: If True, return a sample and its log probability
        """
        h = obs
        for i, fc in enumerate(self.fcs):
            h = self.hidden_activation(fc(h))
        mean = self.last_fc(h)

        if self.std is None:
            log_std = self.last_fc_log_std(h)
            log_std = torch.clamp(log_std, TanhGaussianPolicy.LOG_SIG_MIN, TanhGaussianPolicy.LOG_SIG_MAX)
            std = torch.exp(log_std)
        else:
            std = self.std
            log_std = self.log_std

        log_prob = None
        entropy = None
        mean_action_log_prob = None
        pre_tanh_value = None
        if deterministic:
            action = torch.tanh(mean)
        else:
            tanh_normal = TanhNormal(mean, std)
            if return_log_prob:
                if reparameterize is True:
                    action, pre_tanh_value = tanh_normal.rsample(
                        return_pretanh_value=True
                    )
                else:
                    action, pre_tanh_value = tanh_normal.sample(
                        return_pretanh_value=True
                    )
                log_prob = tanh_normal.log_prob(
                    action,
                    pre_tanh_value=pre_tanh_value
                )
                log_prob = log_prob.sum(dim=1, keepdim=True)
            else:
                if reparameterize is True:
                    action = tanh_normal.rsample()
                else:
                    action = tanh_normal.sample()

        return (
            action, log_prob, entropy, std,
            mean_action_log_prob, pre_tanh_value,
        )


class MakeDeterministic(Policy):
    def __init__(self, stochastic_policy):
        self.stochastic_policy = stochastic_policy

    def get_action(self, observation):
        return self.stochastic_policy.get_action(observation,
                                                 deterministic=True)

    def get_actions(self, observations):
        return self.stochastic_policy.get_actions(observations,
                                                  deterministic=True)
