import numpy as np
from rlkit.data_management.simple_replay_buffer import SimpleReplayBuffer
from gym.spaces import Box, Discrete, Tuple, MultiDiscrete


class EnvReplayBuffer(SimpleReplayBuffer):
    def __init__(
            self,
            max_replay_buffer_size,
            env,
    ):
        """
        :param max_replay_buffer_size:
        :param env:
        """
        self.env = env
        self._ob_space = env.observation_space
        self._action_space = env.action_space
        super().__init__(
            max_replay_buffer_size=max_replay_buffer_size,
            observation_dim=get_dim(self._ob_space),
            action_dim=get_dim(self._action_space),
        )

    def add_sample(self, observation, action, reward, terminal,
            next_observation, **kwargs):

        if isinstance(self._action_space, Discrete):
            action = np.eye(self._action_space.n)[action]
        elif isinstance(self._action_space, MultiDiscrete):
            # Ravel onehot vector
            action = action.ravel()
        super(EnvReplayBuffer, self).add_sample(
                observation, action, reward, terminal, 
                next_observation, **kwargs)


def get_dim(space):
    if isinstance(space, Box):
        return list(space.shape)[::-1]
    elif isinstance(space, Discrete):
        return [space.n]
    elif isinstance(space, MultiDiscrete):
        return [np.sum(space.nvec)]
    elif isinstance(space, Tuple):
        return [sum(get_dim(subspace) for subspace in space.spaces)]
    elif hasattr(space, 'flat_dim'):
        return [space.flat_dim]
    else:
        raise TypeError("Unknown space: {}".format(space))
